/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 96.25, "KoPercent": 3.75};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.1192156862745098, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.04, 500, 1500, "Home-6"], "isController": false}, {"data": [0.0033333333333333335, 500, 1500, "Home-7"], "isController": false}, {"data": [0.0, 500, 1500, "View Allocation"], "isController": false}, {"data": [0.33666666666666667, 500, 1500, "Home-2"], "isController": false}, {"data": [0.0, 500, 1500, "Home-3"], "isController": false}, {"data": [0.16666666666666666, 500, 1500, "Home-4"], "isController": false}, {"data": [0.06333333333333334, 500, 1500, "Home-5"], "isController": false}, {"data": [0.43333333333333335, 500, 1500, "Schedule session page"], "isController": false}, {"data": [0.0, 500, 1500, "Allocate Trainer"], "isController": false}, {"data": [0.14333333333333334, 500, 1500, "Home-0"], "isController": false}, {"data": [0.38, 500, 1500, "Home-1"], "isController": false}, {"data": [0.03333333333333333, 500, 1500, "Trainer allocate page"], "isController": false}, {"data": [0.006666666666666667, 500, 1500, "Trainer list"], "isController": false}, {"data": [0.0, 500, 1500, "Test"], "isController": true}, {"data": [0.42, 500, 1500, "Admin login"], "isController": false}, {"data": [0.0, 500, 1500, "Admin Home"], "isController": false}, {"data": [0.0, 500, 1500, "Home"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 2400, 90, 3.75, 9645.357499999998, 1, 110511, 4232.5, 26217.500000000007, 32379.399999999947, 77637.4199999999, 16.210520627887497, 3121.3772098443455, 11.840236559620944], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["Home-6", 150, 0, 0.0, 5228.666666666668, 1023, 14996, 4702.0, 9270.700000000003, 9694.0, 14272.820000000012, 3.5685397535328547, 206.38984215159158, 1.669268107365466], "isController": false}, {"data": ["Home-7", 150, 0, 0.0, 15607.500000000005, 1457, 41366, 15972.0, 24752.4, 28708.35, 37296.71000000007, 2.5432781159395716, 849.2214257405178, 1.1822269367062852], "isController": false}, {"data": ["View Allocation", 150, 86, 57.333333333333336, 45099.25333333334, 1, 110511, 30497.0, 83604.3, 92291.89999999998, 105188.13000000009, 1.1468240618979173, 1379.4328781795698, 0.5744722459020154], "isController": false}, {"data": ["Home-2", 150, 0, 0.0, 1802.5199999999998, 84, 6418, 1743.0, 3424.9, 3737.799999999999, 5562.730000000015, 4.8979591836734695, 153.49623724489797, 2.3628826530612246], "isController": false}, {"data": ["Home-3", 150, 0, 0.0, 8916.6, 1523, 18537, 8593.5, 15362.100000000002, 16196.9, 18148.38000000001, 3.840934115176811, 641.11716969567, 1.7966869542672779], "isController": false}, {"data": ["Home-4", 150, 0, 0.0, 3066.7933333333335, 239, 7920, 2739.0, 5990.1, 6684.349999999999, 7892.460000000001, 4.591368227731864, 6.313131313131313, 2.1477200987144167], "isController": false}, {"data": ["Home-5", 150, 0, 0.0, 4695.900000000001, 481, 20733, 4392.0, 7739.1, 9726.05, 15848.220000000087, 3.9714058776806986, 145.06878599086576, 1.86547483121525], "isController": false}, {"data": ["Schedule session page", 150, 0, 0.0, 1635.7000000000005, 326, 9664, 1159.0, 3763.500000000001, 3892.999999999999, 9423.790000000005, 1.6180531584397653, 0.29390418698222304, 1.8756143545585953], "isController": false}, {"data": ["Allocate Trainer", 150, 0, 0.0, 8052.293333333333, 2724, 15434, 7605.5, 13508.800000000001, 13901.2, 15209.090000000004, 1.687535860137028, 137.975832377063, 0.8651917251679098], "isController": false}, {"data": ["Home-0", 150, 0, 0.0, 2724.3599999999988, 950, 15597, 2504.0, 4685.100000000001, 5627.699999999997, 11142.66000000008, 5.33864825426202, 18.66441479517386, 2.356512705982845], "isController": false}, {"data": ["Home-1", 150, 0, 0.0, 2149.5533333333333, 238, 8898, 1144.5, 5192.4, 6596.249999999997, 8676.150000000003, 4.6986593158752035, 6.910332939168025, 2.1611997439230675], "isController": false}, {"data": ["Trainer allocate page", 150, 0, 0.0, 3387.480000000001, 704, 7179, 3315.5, 5402.900000000001, 5801.2, 7132.590000000001, 1.6177041542642683, 1.1943206451404167, 0.8515063858871489], "isController": false}, {"data": ["Trainer list", 150, 4, 2.6666666666666665, 4253.653333333333, 1315, 10783, 3737.0, 7354.0, 7590.5, 10046.560000000012, 1.511137080281676, 0.3743015713307073, 0.8544417670733304], "isController": false}, {"data": ["Test", 150, 86, 57.333333333333336, 110133.82666666666, 88937, 142863, 105590.5, 134123.30000000002, 138461.6, 141737.94000000003, 1.0131643825438532, 2480.1968842240176, 8.069643231048762], "isController": true}, {"data": ["Admin login", 150, 0, 0.0, 1197.5333333333328, 246, 4731, 1021.5, 2140.3, 2784.899999999999, 3995.580000000013, 2.5551050999897797, 1.200200735444418, 1.1952102957960002], "isController": false}, {"data": ["Admin Home", 150, 0, 0.0, 26869.573333333323, 6857, 50329, 27072.5, 36905.600000000006, 41354.95, 48917.32000000002, 1.7610594533671455, 931.3768788303042, 0.8994473575302901], "isController": false}, {"data": ["Home", 150, 0, 0.0, 19638.339999999993, 3930, 42683, 21103.0, 32188.20000000001, 35447.799999999996, 41471.75000000002, 2.494719510369717, 1578.833298944318, 9.284546927752922], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["503/Service Unavailable", 86, 95.55555555555556, 3.5833333333333335], "isController": false}, {"data": ["Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: trainermanagement.herokuapp.com:443 failed to respond", 4, 4.444444444444445, 0.16666666666666666], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 2400, 90, "503/Service Unavailable", 86, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: trainermanagement.herokuapp.com:443 failed to respond", 4, null, null, null, null, null, null], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["View Allocation", 150, 86, "503/Service Unavailable", 82, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: trainermanagement.herokuapp.com:443 failed to respond", 4, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["Trainer list", 150, 4, "503/Service Unavailable", 4, null, null, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
