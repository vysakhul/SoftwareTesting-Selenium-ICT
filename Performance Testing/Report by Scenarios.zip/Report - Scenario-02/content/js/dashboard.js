/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 86.88888888888889, "KoPercent": 13.11111111111111};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.21395833333333333, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.0, 500, 1500, "Save Profile"], "isController": false}, {"data": [0.04666666666666667, 500, 1500, "Home-6"], "isController": false}, {"data": [0.0, 500, 1500, "Home-7"], "isController": false}, {"data": [0.3566666666666667, 500, 1500, "Trainer Profile page"], "isController": false}, {"data": [0.4866666666666667, 500, 1500, "Home-2"], "isController": false}, {"data": [0.0, 500, 1500, "Home-3"], "isController": false}, {"data": [0.19333333333333333, 500, 1500, "Home-4"], "isController": false}, {"data": [0.07666666666666666, 500, 1500, "Home-5"], "isController": false}, {"data": [0.41, 500, 1500, "Login"], "isController": false}, {"data": [0.16666666666666666, 500, 1500, "Home-0"], "isController": false}, {"data": [0.49333333333333335, 500, 1500, "Home-1"], "isController": false}, {"data": [0.0, 500, 1500, "Test"], "isController": true}, {"data": [0.84, 500, 1500, "MyAllocation"], "isController": false}, {"data": [0.023333333333333334, 500, 1500, "Back to Profile page"], "isController": false}, {"data": [0.33, 500, 1500, "Trainer Profile page 2"], "isController": false}, {"data": [0.0, 500, 1500, "Home"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 2250, 295, 13.11111111111111, 5608.57777777778, 0, 31229, 2288.5, 17519.700000000008, 30235.0, 30559.449999999997, 29.479587023740894, 2500.2570251493635, 20.653751809719093], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["Save Profile", 150, 150, 100.0, 30358.36666666667, 30227, 31229, 30279.5, 30583.5, 30622.45, 30959.210000000006, 2.1695111368238353, 1.5148442019814867, 1.9152715504772924], "isController": false}, {"data": ["Home-6", 150, 0, 0.0, 4341.5133333333315, 502, 11071, 4307.5, 7276.500000000001, 8197.0, 10548.76000000001, 4.968203497615263, 287.3407069753577, 2.3239936282790143], "isController": false}, {"data": ["Home-7", 150, 0, 0.0, 11454.113333333335, 2213, 26931, 11621.5, 18039.1, 20071.899999999998, 25123.560000000034, 3.9032006245121, 1303.310706967213, 1.8143784153005464], "isController": false}, {"data": ["Trainer Profile page", 150, 0, 0.0, 1548.44, 447, 3823, 1083.5, 2872.0, 3303.3999999999896, 3815.3500000000004, 3.8131069195180234, 4.658395269840867, 2.085292846611419], "isController": false}, {"data": ["Home-2", 150, 0, 0.0, 1276.2600000000004, 72, 5772, 1050.0, 2571.8, 3281.0, 5323.200000000008, 5.693247808099594, 178.4206411664516, 2.746547282423046], "isController": false}, {"data": ["Home-3", 150, 0, 0.0, 7172.4800000000005, 1652, 17530, 6598.0, 12319.7, 13378.599999999995, 17316.310000000005, 4.530627038782168, 756.2386380368794, 2.1193069839615806], "isController": false}, {"data": ["Home-4", 150, 0, 0.0, 2293.72, 246, 9232, 2088.0, 4264.500000000001, 5378.149999999993, 7862.650000000024, 5.014039310068191, 6.894304051343762, 2.345434403830726], "isController": false}, {"data": ["Home-5", 150, 0, 0.0, 3698.146666666666, 787, 9296, 3434.0, 6557.500000000001, 7845.099999999998, 9107.300000000003, 4.993508439029261, 182.40447574403274, 2.345583553879956], "isController": false}, {"data": ["Login", 150, 0, 0.0, 1401.3066666666666, 430, 3797, 1017.5, 3050.9, 3462.6999999999994, 3742.940000000001, 3.95987328405491, 2.034075534582893, 1.887127111932418], "isController": false}, {"data": ["Home-0", 150, 0, 0.0, 2163.9800000000005, 900, 6148, 2057.0, 3724.5, 4179.699999999996, 5893.510000000005, 6.303580433686334, 22.037908156833083, 2.7824398008068583], "isController": false}, {"data": ["Home-1", 150, 0, 0.0, 1340.34, 231, 5693, 682.5, 3606.700000000001, 4082.949999999999, 5203.400000000009, 5.673007828750804, 8.343310341893272, 2.609361999357059], "isController": false}, {"data": ["Test", 150, 150, 100.0, 50388.11333333332, 38341, 65951, 51413.5, 58812.3, 60930.6, 65637.86, 1.9652800524074678, 1256.457006939895, 13.33933835571569], "isController": true}, {"data": ["MyAllocation", 150, 0, 0.0, 816.3666666666666, 420, 4419, 431.0, 2270.6000000000004, 3452.9999999999986, 4415.43, 3.708373507379663, 5.019341485574428, 2.009909469331751], "isController": false}, {"data": ["Back to Profile page", 150, 145, 96.66666666666667, 28.213333333333335, 0, 1113, 0.0, 1.0, 1.0, 1112.49, 3.747938633751437, 7.554194802233772, 0.0746659649692669], "isController": false}, {"data": ["Trainer Profile page 2", 150, 0, 0.0, 1570.7333333333327, 418, 3797, 1145.5, 2881.0, 2894.45, 3794.96, 3.8141734686093525, 2.49560178121901, 2.279564612098558], "isController": false}, {"data": ["Home", 150, 0, 0.0, 14664.68666666667, 3545, 29111, 15796.0, 21488.1, 22856.5, 27259.19000000003, 3.7990071927869518, 2404.2785972245088, 14.138687902061594], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["503/Service Unavailable", 150, 50.847457627118644, 6.666666666666667], "isController": false}, {"data": ["Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: trainermanagement.herokuapp.com:443 failed to respond", 145, 49.152542372881356, 6.444444444444445], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 2250, 295, "503/Service Unavailable", 150, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: trainermanagement.herokuapp.com:443 failed to respond", 145, null, null, null, null, null, null], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": ["Save Profile", 150, 150, "503/Service Unavailable", 150, null, null, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["Back to Profile page", 150, 145, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: trainermanagement.herokuapp.com:443 failed to respond", 145, null, null, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
