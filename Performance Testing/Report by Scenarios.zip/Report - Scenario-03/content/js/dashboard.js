/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 98.76190476190476, "KoPercent": 1.2380952380952381};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.11, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.013333333333333334, 500, 1500, "Search trainer list"], "isController": false}, {"data": [0.02, 500, 1500, "Home-6"], "isController": false}, {"data": [0.0, 500, 1500, "Home-7"], "isController": false}, {"data": [0.37333333333333335, 500, 1500, "Home-2"], "isController": false}, {"data": [0.0033333333333333335, 500, 1500, "Home-3"], "isController": false}, {"data": [0.16, 500, 1500, "Home-4"], "isController": false}, {"data": [0.05333333333333334, 500, 1500, "Home-5"], "isController": false}, {"data": [0.13666666666666666, 500, 1500, "Home-0"], "isController": false}, {"data": [0.39, 500, 1500, "Home-1"], "isController": false}, {"data": [0.07333333333333333, 500, 1500, "Approve Trainer"], "isController": false}, {"data": [0.0, 500, 1500, "Trainer list"], "isController": false}, {"data": [0.0, 500, 1500, "Test"], "isController": true}, {"data": [0.4266666666666667, 500, 1500, "Admin login"], "isController": false}, {"data": [0.0, 500, 1500, "Admin Home"], "isController": false}, {"data": [0.0, 500, 1500, "Home"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 2100, 26, 1.2380952380952381, 7278.810476190474, 74, 32157, 4684.0, 17932.9, 22214.9, 26773.699999999993, 25.50772519677388, 3315.7124740367794, 18.884352073413663], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["Search trainer list", 150, 0, 0.0, 6964.366666666669, 1234, 12583, 6689.5, 10629.7, 11214.699999999997, 12490.690000000002, 2.23260798380615, 182.54186605096297, 1.144647647947489], "isController": false}, {"data": ["Home-6", 150, 0, 0.0, 5583.899999999998, 776, 13894, 5165.5, 9974.100000000002, 11744.55, 13880.74, 4.183867008814013, 241.97787083007924, 1.957101852755774], "isController": false}, {"data": ["Home-7", 150, 13, 8.666666666666666, 13991.080000000002, 2264, 25515, 14476.5, 21599.0, 22459.699999999997, 25454.31, 3.3971237685426336, 1036.7939025167025, 1.4422736666289209], "isController": false}, {"data": ["Home-2", 150, 0, 0.0, 1831.2266666666665, 74, 5357, 1444.0, 3610.7000000000003, 3934.2999999999997, 4922.990000000008, 4.935184575903139, 154.66161598506284, 2.380840996578272], "isController": false}, {"data": ["Home-3", 150, 0, 0.0, 9458.046666666665, 1258, 20622, 9808.5, 15802.4, 18062.199999999993, 20079.360000000008, 3.72079178449174, 621.063373223322, 1.7404875632534604], "isController": false}, {"data": ["Home-4", 150, 0, 0.0, 2877.2733333333335, 258, 8833, 2679.5, 5195.1, 5965.949999999999, 8356.660000000009, 4.706620646375902, 6.471603388766865, 2.2016321187637278], "isController": false}, {"data": ["Home-5", 150, 0, 0.0, 4784.313333333334, 511, 29897, 4735.0, 7724.400000000001, 9346.349999999997, 20016.260000000177, 3.5895472384416576, 131.1201313026467, 1.686105685244568], "isController": false}, {"data": ["Home-0", 150, 0, 0.0, 2710.2466666666655, 958, 8247, 2543.5, 4867.700000000002, 5486.699999999996, 7350.420000000016, 5.472654967346492, 19.132914827246527, 2.4156641066802877], "isController": false}, {"data": ["Home-1", 150, 0, 0.0, 1943.2133333333331, 239, 8021, 1192.0, 4754.400000000001, 5135.449999999998, 6944.390000000019, 4.744883434030304, 6.9783148941891, 2.182461032644798], "isController": false}, {"data": ["Approve Trainer", 150, 0, 0.0, 3453.2866666666673, 1020, 6652, 3420.5, 5579.000000000001, 6180.299999999997, 6642.82, 2.501125506477915, 0.45430600020009004, 2.3692302160972436], "isController": false}, {"data": ["Trainer list", 150, 0, 0.0, 11211.486666666662, 2037, 17132, 12441.0, 15322.7, 15911.8, 17031.530000000002, 2.26090888537192, 0.5321084388424147, 1.2739691668550757], "isController": false}, {"data": ["Test", 150, 13, 8.666666666666666, 58724.04666666667, 19397, 70298, 61599.0, 66461.4, 68418.9, 70244.45, 1.8219803711981342, 2214.9463075669883, 12.17692587121028], "isController": true}, {"data": ["Admin login", 150, 0, 0.0, 1203.9599999999998, 250, 3978, 969.0, 2329.2000000000003, 2704.3999999999996, 3907.6200000000013, 3.5555134161372903, 1.6701190948848013, 1.6631747327439081], "isController": false}, {"data": ["Admin Home", 150, 0, 0.0, 17491.81333333334, 7607, 29062, 16456.5, 25875.600000000002, 27730.45, 28922.770000000004, 2.3830706659888157, 1260.3418440399403, 1.2171347249142095], "isController": false}, {"data": ["Home", 150, 13, 8.666666666666666, 18399.13333333334, 3519, 32157, 20268.0, 25842.7, 26781.65, 31197.18000000002, 3.3157231592210263, 2003.2245839458212, 12.206480788147395], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket closed", 13, 50.0, 0.6190476190476191], "isController": false}, {"data": ["Assertion failed", 13, 50.0, 0.6190476190476191], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 2100, 26, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket closed", 13, "Assertion failed", 13, null, null, null, null, null, null], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["Home-7", 150, 13, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket closed", 13, null, null, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["Home", 150, 13, "Assertion failed", 13, null, null, null, null, null, null, null, null], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
