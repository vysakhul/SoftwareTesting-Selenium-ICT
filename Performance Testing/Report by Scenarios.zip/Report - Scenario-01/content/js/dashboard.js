/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 96.69135802469135, "KoPercent": 3.308641975308642};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.4711904761904762, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.04666666666666667, 500, 1500, "Home-6"], "isController": false}, {"data": [0.0, 500, 1500, "Home-7"], "isController": false}, {"data": [0.30666666666666664, 500, 1500, "Sign Up-7"], "isController": false}, {"data": [0.4666666666666667, 500, 1500, "Home-2"], "isController": false}, {"data": [0.7966666666666666, 500, 1500, "Sign Up-4"], "isController": false}, {"data": [0.0033333333333333335, 500, 1500, "Home-3"], "isController": false}, {"data": [0.8066666666666666, 500, 1500, "Sign Up-3"], "isController": false}, {"data": [0.19666666666666666, 500, 1500, "Home-4"], "isController": false}, {"data": [0.78, 500, 1500, "Sign Up-6"], "isController": false}, {"data": [0.06333333333333334, 500, 1500, "Home-5"], "isController": false}, {"data": [0.7866666666666666, 500, 1500, "Sign Up-5"], "isController": false}, {"data": [0.73, 500, 1500, "Login-0"], "isController": false}, {"data": [0.77, 500, 1500, "Sign Up-0"], "isController": false}, {"data": [0.7566666666666667, 500, 1500, "Login-1"], "isController": false}, {"data": [0.19333333333333333, 500, 1500, "Home-0"], "isController": false}, {"data": [0.8666666666666667, 500, 1500, "Login-2"], "isController": false}, {"data": [0.9066666666666666, 500, 1500, "Sign Up-2"], "isController": false}, {"data": [0.4666666666666667, 500, 1500, "Home-1"], "isController": false}, {"data": [0.7533333333333333, 500, 1500, "Login-3"], "isController": false}, {"data": [0.79, 500, 1500, "Sign Up-1"], "isController": false}, {"data": [0.76, 500, 1500, "Login-4"], "isController": false}, {"data": [0.7433333333333333, 500, 1500, "Login-5"], "isController": false}, {"data": [0.7366666666666667, 500, 1500, "Login-6"], "isController": false}, {"data": [0.17666666666666667, 500, 1500, "Login-7"], "isController": false}, {"data": [0.0, 500, 1500, "Test"], "isController": true}, {"data": [0.0, 500, 1500, "Home"], "isController": false}, {"data": [0.09, 500, 1500, "Login"], "isController": false}, {"data": [0.2, 500, 1500, "Sign Up"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 4050, 134, 3.308641975308642, 2266.2864197530766, 12, 23935, 745.5, 6201.4000000000015, 10541.8, 17278.229999999974, 104.63223706306353, 5010.684134168238, 93.8850288707469], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["Home-6", 150, 0, 0.0, 3867.0733333333324, 566, 10379, 3455.0, 6533.5, 7155.7, 9317.690000000019, 5.0471063257065945, 291.9041260094213, 2.3609022754037685], "isController": false}, {"data": ["Home-7", 150, 48, 32.0, 8690.093333333334, 162, 20894, 8891.0, 15390.5, 17033.94999999999, 20605.340000000004, 4.364398149495185, 994.7980977134191, 1.3795589775669934], "isController": false}, {"data": ["Sign Up-7", 150, 10, 6.666666666666667, 1739.6933333333327, 232, 17343, 1018.5, 2715.3, 3604.499999999996, 16607.580000000013, 4.487121959974872, 62.06326514777588, 2.291236650812169], "isController": false}, {"data": ["Home-2", 150, 0, 0.0, 1230.02, 70, 7363, 921.5, 2562.9, 2762.95, 5974.270000000025, 5.603287261860292, 175.59903372478522, 2.703148347030258], "isController": false}, {"data": ["Sign Up-4", 150, 0, 0.0, 517.6133333333335, 224, 7731, 327.5, 792.0000000000002, 1058.1999999999994, 5500.26000000004, 4.561488869967157, 1.3051916395511496, 2.5168371206361755], "isController": false}, {"data": ["Home-3", 150, 0, 0.0, 6405.753333333333, 958, 14223, 6192.0, 10621.9, 12306.199999999999, 13679.34000000001, 4.517255917605252, 754.0067707078539, 2.1130523286454252], "isController": false}, {"data": ["Sign Up-3", 150, 0, 0.0, 503.80666666666724, 229, 6119, 311.5, 725.6, 1078.549999999997, 4894.490000000022, 4.561488869967157, 1.314100797500304, 2.52574627858533], "isController": false}, {"data": ["Home-4", 150, 0, 0.0, 2217.7400000000007, 239, 5720, 2137.5, 3944.2, 4453.3499999999985, 5373.710000000006, 5.394519168524779, 7.417463856721571, 2.5234127751204776], "isController": false}, {"data": ["Sign Up-6", 150, 0, 0.0, 556.7333333333331, 228, 7316, 352.5, 867.3000000000001, 1464.4999999999995, 5486.630000000033, 4.561488869967157, 1.3096462185257267, 2.521291699610753], "isController": false}, {"data": ["Home-5", 150, 0, 0.0, 3518.139999999999, 523, 9624, 2986.0, 6752.400000000001, 7894.799999999998, 9119.61000000001, 4.893485140116791, 178.7507926426451, 2.298599953511891], "isController": false}, {"data": ["Sign Up-5", 150, 0, 0.0, 547.5466666666667, 225, 6780, 312.0, 815.3000000000003, 1732.2999999999956, 5243.370000000027, 4.561488869967157, 1.3096462185257267, 2.5302008575599073], "isController": false}, {"data": ["Login-0", 150, 0, 0.0, 606.6533333333333, 223, 2626, 478.5, 1168.1000000000004, 1700.1999999999996, 2375.0800000000045, 4.57484445528852, 16.137048996584117, 2.0417030430340373], "isController": false}, {"data": ["Sign Up-0", 150, 0, 0.0, 553.1066666666669, 231, 2766, 406.0, 1266.2000000000019, 1807.3499999999992, 2709.900000000001, 4.557192769254139, 16.07478543217378, 2.0382756721859336], "isController": false}, {"data": ["Login-1", 150, 0, 0.0, 516.3599999999999, 232, 2812, 465.0, 783.7, 1004.8999999999984, 2660.5300000000025, 4.479082683866344, 1.2816125257547255, 2.4363760301890176], "isController": false}, {"data": ["Home-0", 150, 0, 0.0, 2038.7066666666665, 899, 7794, 1716.0, 3609.8, 4089.2, 6504.720000000023, 5.98014591556034, 20.907150759478533, 2.6396737830403065], "isController": false}, {"data": ["Login-2", 150, 0, 0.0, 306.40666666666675, 27, 866, 217.0, 693.3000000000001, 764.7499999999998, 860.9000000000001, 4.6039102544427735, 4.582149584880758, 2.598691530339768], "isController": false}, {"data": ["Sign Up-2", 150, 0, 0.0, 231.68666666666675, 23, 850, 114.5, 578.9, 731.1999999999998, 845.4100000000001, 4.589963280293758, 4.571615380201958, 2.5908191171970625], "isController": false}, {"data": ["Home-1", 150, 0, 0.0, 1428.0733333333333, 230, 5990, 821.0, 3361.0000000000005, 3705.399999999999, 5741.120000000004, 5.445634416409511, 8.00891155382102, 2.5047791114539844], "isController": false}, {"data": ["Login-3", 150, 0, 0.0, 526.3266666666667, 230, 2541, 479.5, 771.6000000000001, 1113.8999999999974, 2351.7900000000036, 4.574704931531916, 1.3179081589862454, 2.5330641564244103], "isController": false}, {"data": ["Sign Up-1", 150, 0, 0.0, 508.11999999999955, 229, 5576, 312.5, 818.2000000000002, 1427.9499999999987, 3971.5400000000286, 4.561488869967157, 1.3051916395511496, 2.481200488839557], "isController": false}, {"data": ["Login-4", 150, 0, 0.0, 533.0466666666666, 226, 2541, 480.0, 801.8, 988.4999999999994, 2381.3700000000026, 4.475741481172047, 1.2806564980306736, 2.4695253289669985], "isController": false}, {"data": ["Login-5", 150, 0, 0.0, 533.0333333333333, 232, 2232, 487.0, 812.9000000000001, 1055.4499999999991, 1969.8600000000047, 4.481625336121899, 1.2867166492381237, 2.4859015536301166], "isController": false}, {"data": ["Login-6", 150, 0, 0.0, 550.2866666666663, 232, 2197, 499.5, 853.9000000000001, 1139.3499999999985, 2185.2700000000004, 4.479082683866344, 1.2859866299381888, 2.4757429678401865], "isController": false}, {"data": ["Login-7", 150, 9, 6.0, 3662.320000000001, 12, 19300, 2161.5, 11052.000000000004, 15086.299999999997, 18830.290000000008, 4.484707148623195, 420.89986816829605, 2.213973786886716], "isController": false}, {"data": ["Test", 150, 61, 40.666666666666664, 19401.393333333337, 5817, 30682, 19481.5, 26273.2, 28870.699999999997, 30271.960000000006, 3.875368159975198, 2505.406794569963, 46.943727232212055], "isController": true}, {"data": ["Home", 150, 48, 32.0, 12217.679999999998, 3548, 23935, 12936.5, 18781.600000000002, 19589.75, 23765.680000000004, 4.221665587796572, 2224.380371629704, 15.08371430933551], "isController": false}, {"data": ["Login", 150, 9, 6.0, 4589.326666666666, 483, 19841, 2929.0, 12336.300000000001, 15856.799999999996, 19401.890000000007, 4.443917757895361, 443.54494328449965, 18.936644545831605], "isController": false}, {"data": ["Sign Up", 150, 10, 6.666666666666667, 2594.386666666666, 508, 18071, 1830.0, 4574.900000000001, 5842.399999999989, 17582.42000000001, 4.420736199935162, 87.4834337515841, 18.917124550558487], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket closed", 66, 49.25373134328358, 1.6296296296296295], "isController": false}, {"data": ["Non HTTP response code: org.apache.http.ConnectionClosedException/Non HTTP response message: Connection is closed", 1, 0.746268656716418, 0.024691358024691357], "isController": false}, {"data": ["Assertion failed", 67, 50.0, 1.654320987654321], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 4050, 134, "Assertion failed", 67, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket closed", 66, "Non HTTP response code: org.apache.http.ConnectionClosedException/Non HTTP response message: Connection is closed", 1, null, null, null, null], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": ["Home-7", 150, 48, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket closed", 48, null, null, null, null, null, null, null, null], "isController": false}, {"data": ["Sign Up-7", 150, 10, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket closed", 10, null, null, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["Login-7", 150, 9, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket closed", 8, "Non HTTP response code: org.apache.http.ConnectionClosedException/Non HTTP response message: Connection is closed", 1, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": ["Home", 150, 48, "Assertion failed", 48, null, null, null, null, null, null, null, null], "isController": false}, {"data": ["Login", 150, 9, "Assertion failed", 9, null, null, null, null, null, null, null, null], "isController": false}, {"data": ["Sign Up", 150, 10, "Assertion failed", 10, null, null, null, null, null, null, null, null], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
